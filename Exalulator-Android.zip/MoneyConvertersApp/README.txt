EXALULATOR - Android app (Android Studio project)

BUILD KARNE KE STEPS
1. Android Studio install karo (developer.android.com/studio), internet on rakho.
2. File > Open > "MoneyConvertersApp" folder select karo.
3. Gradle sync khud hoga (pehli baar kuch minute lagte hain).
4. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s)
5. APK yahan milegi: app/build/outputs/apk/debug/app-debug.apk
6. APK phone me bhejo/USB se copy karo, install karo ("Install unknown apps" allow karna pe sakta hai).

NOTIFICATION KE LIYE (zaroori)
- Pehli baar app khulne pe "Allow notifications" pe Allow dabao.
- Exchanges screen me Reminder ON rakho. Jab tak koi order "Pending" hai, har 1 ghante baad
  "Exchange pending" notification aayegi - app band ho tab bhi. Pending na ho to nahi aayegi.
- Reminder Android WorkManager se chalta hai, isliye app swipe ya phone restart ke baad bhi chalta rehta hai.
- Xiaomi/Oppo/Vivo/Infinix/Tecno/Realme phones: Settings > Apps > Exalulator >
  Battery > "No restrictions" / "Unrestricted" karo, aur Autostart ON karo. Warna phone
  app ko kill kar ke notification rok sakta hai.
- Android battery saving ki wajah se timing me kuch minute ka farq ho sakta hai.

NOTE: Reminder ka timing Android decide karta hai (har ~1 ghanta), kuch minute aage peeche ho sakta hai. App ko 'Force stop' karoge to wo band ho jata hai.

NOTES
- Live rates ke liye INTERNET permission hai. Offline ho to purane saved rates chalte hain.
- Screenshot Save = Gallery > Pictures/Exchange. Share = seedha apps ki list.
- Back button: sheet band karta hai, phir Home, phir app background me.
- app/src/main/assets/index.html asal app hai. browser-test.html wahi file hai browser me test ke liye.
- Package name: com.exchange.converter. App ka naam strings.xml me hai.
