package com.exchange.converter;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl(startUrl(getIntent()));

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private String startUrl(Intent i) {
        String u = "file:///android_asset/index.html";
        if (i != null && i.getBooleanExtra("openExchanges", false)) u += "#exchanges";
        return u;
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        if (i != null && i.getBooleanExtra("openExchanges", false)) {
            web.evaluateJavascript("location.hash='#exchanges'", null);
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(function(){try{return window.appBack?String(!!window.appBack()):'false'}catch(e){return 'false'}})()", v -> {
            if (v == null || v.contains("false")) moveTaskToBack(true);
        });
    }

    private Uri saveToGallery(String b64, String name) throws Exception {
        byte[] data = Base64.decode(b64, Base64.DEFAULT);
        ContentResolver cr = getContentResolver();
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Exchange");
        Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
        if (uri == null) throw new Exception("insert failed");
        try (OutputStream os = cr.openOutputStream(uri)) { os.write(data); }
        return uri;
    }

    class Bridge {
        @JavascriptInterface
        public boolean saveImage(String b64, String name) {
            try {
                saveToGallery(b64, name);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Saved to Gallery (Pictures/Exchange)", Toast.LENGTH_SHORT).show());
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public boolean shareImage(String b64, String name) {
            try {
                final Uri uri = saveToGallery(b64, name);
                runOnUiThread(() -> {
                    Intent it = new Intent(Intent.ACTION_SEND);
                    it.setType("image/png");
                    it.putExtra(Intent.EXTRA_STREAM, uri);
                    it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(it, "Share"));
                });
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public void setReminder(boolean enabled, String title, String body) {
            Reminder.set(MainActivity.this, enabled, title, body);
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                }
            });
        }
    }
}
