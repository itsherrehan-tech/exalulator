package com.exchange.converter;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class ReminderWorker extends Worker {
    public ReminderWorker(@NonNull Context c, @NonNull WorkerParameters p) {
        super(c, p);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context c = getApplicationContext();
        if (Reminder.sp(c).getBoolean("enabled", false)) {
            try { Reminder.show(c); } catch (Exception e) { }
        }
        return Result.success();
    }
}
