package com.exchange.converter;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!Reminder.sp(c).getBoolean("enabled", false)) {
            Reminder.cancel(c);
            return;
        }
        try { Reminder.show(c); } catch (Exception e) { }
        Reminder.schedule(c);
    }
}
