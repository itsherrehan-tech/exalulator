package com.exchange.converter;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class Reminder {
    // Hourly. Change to 60000 (1 minute) for quick testing.
    static final long HOUR = 60L * 60L * 1000L;
    static final String CH = "pending_exchanges";

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("reminder", Context.MODE_PRIVATE);
    }

    static void set(Context c, boolean enabled, String title, String body) {
        SharedPreferences p = sp(c);
        boolean was = p.getBoolean("scheduled", false);
        p.edit().putBoolean("enabled", enabled).putString("title", title).putString("body", body).apply();
        if (enabled) {
            if (!was) schedule(c);
        } else {
            cancel(c);
        }
    }

    static PendingIntent pi(Context c) {
        Intent i = new Intent(c, ReminderReceiver.class);
        return PendingIntent.getBroadcast(c, 7, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + HOUR, pi(c));
        sp(c).edit().putBoolean("scheduled", true).apply();
    }

    static void cancel(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pi(c));
        sp(c).edit().putBoolean("scheduled", false).apply();
    }

    static void show(Context c) {
        SharedPreferences p = sp(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH, "Pending exchanges", NotificationManager.IMPORTANCE_HIGH));
        Intent open = new Intent(c, MainActivity.class);
        open.putExtra("openExchanges", true);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(c, 8, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(p.getString("title", "Exchange pending"))
                .setContentText(p.getString("body", "You have pending exchanges."))
                .setStyle(new Notification.BigTextStyle().bigText(p.getString("body", "You have pending exchanges.")))
                .setContentIntent(content)
                .setAutoCancel(true)
                .build();
        nm.notify(1, n);
    }
}
