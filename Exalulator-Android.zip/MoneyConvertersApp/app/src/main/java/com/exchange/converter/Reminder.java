package com.exchange.converter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public class Reminder {
    static final String WORK = "pending_reminder";
    static final String CH = "pending_exchanges";

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("reminder", Context.MODE_PRIVATE);
    }

    // Hourly reminder using WorkManager (survives app swipe, reboot, battery savers better than alarms).
    // KEEP: if it is already scheduled, the old schedule continues; only the saved text is updated.
    static void set(Context c, boolean enabled, String title, String body) {
        sp(c).edit().putBoolean("enabled", enabled).putString("title", title).putString("body", body).apply();
        WorkManager wm = WorkManager.getInstance(c);
        if (enabled) {
            PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(ReminderWorker.class, 1, TimeUnit.HOURS)
                    .setInitialDelay(1, TimeUnit.HOURS)
                    .build();
            wm.enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req);
        } else {
            wm.cancelUniqueWork(WORK);
        }
    }

    static void show(Context c) {
        SharedPreferences p = sp(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH, "Pending exchanges", NotificationManager.IMPORTANCE_HIGH));
        Intent open = new Intent(c, MainActivity.class);
        open.putExtra("openExchanges", true);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(c, 8, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(p.getString("title", "Exchange pending"))
                .setContentText(p.getString("body", "You have pending exchanges."))
                .setStyle(new Notification.BigTextStyle().bigText(p.getString("body", "You have pending exchanges.")))
                .setContentIntent(content)
                .setAutoCancel(true)
                .build();
        nm.notify(1, n);
    }
}
